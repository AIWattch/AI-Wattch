import React from "react";

interface GeminiLogoProps {
  size?: number;
}

export const GeminiLogo: React.FC<GeminiLogoProps> = ({ size = 13 }) => {
  return (
    <svg
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 65 65"
      width={size}
      height={size}
    >
      <mask
        id="b"
        style={{
          maskType: "alpha",
        }}
        maskUnits="userSpaceOnUse"
        x={0}
        y={0}
        width={65}
        height={65}
      >
        <path
          d="M32.447 0c.68 0 1.273.465 1.439 1.125a39 39 0 0 0 1.999 5.905q3.23 7.5 8.854 13.125 5.626 5.626 13.125 8.855a39 39 0 0 0 5.906 1.999c.66.166 1.124.758 1.124 1.438s-.464 1.273-1.125 1.439a39 39 0 0 0-5.905 1.999q-7.5 3.23-13.125 8.854-5.625 5.626-8.854 13.125a39 39 0 0 0-2 5.906 1.485 1.485 0 0 1-1.438 1.124c-.68 0-1.272-.464-1.438-1.125a39 39 0 0 0-2-5.905q-3.227-7.5-8.854-13.125-5.625-5.625-13.125-8.854a39 39 0 0 0-5.905-2A1.485 1.485 0 0 1 0 32.448c0-.68.465-1.272 1.125-1.438a39 39 0 0 0 5.905-2q7.5-3.228 13.125-8.854 5.626-5.624 8.855-13.125a39 39 0 0 0 1.999-5.905A1.485 1.485 0 0 1 32.447 0"
          fill="#000"
        />
        <path
          d="M32.447 0c.68 0 1.273.465 1.439 1.125a39 39 0 0 0 1.999 5.905q3.23 7.5 8.854 13.125 5.626 5.626 13.125 8.855a39 39 0 0 0 5.906 1.999c.66.166 1.124.758 1.124 1.438s-.464 1.273-1.125 1.439a39 39 0 0 0-5.905 1.999q-7.5 3.23-13.125 8.854-5.625 5.626-8.854 13.125a39 39 0 0 0-2 5.906 1.485 1.485 0 0 1-1.438 1.124c-.68 0-1.272-.464-1.438-1.125a39 39 0 0 0-2-5.905q-3.227-7.5-8.854-13.125-5.625-5.625-13.125-8.854a39 39 0 0 0-5.905-2A1.485 1.485 0 0 1 0 32.448c0-.68.465-1.272 1.125-1.438a39 39 0 0 0 5.905-2q7.5-3.228 13.125-8.854 5.626-5.624 8.855-13.125a39 39 0 0 0 1.999-5.905A1.485 1.485 0 0 1 32.447 0"
          fill="url(#a)"
        />
      </mask>
      <g mask="url(#b)">
        <g filter="url(#c)">
          <path
            d="M-5.859 50.734c7.498 2.663 16.116-2.33 19.249-11.152s-.406-18.131-7.904-20.794-16.116 2.33-19.25 11.151c-3.132 8.822.407 18.132 7.905 20.795"
            fill="#ffe432"
          />
        </g>
        <g filter="url(#d)">
          <path
            d="M27.433 21.649c10.3 0 18.651-8.535 18.651-19.062s-8.35-19.062-18.651-19.062S8.78-7.94 8.78 2.587s8.35 19.062 18.652 19.062z"
            fill="#fc413d"
          />
        </g>
        <g filter="url(#e)">
          <path
            d="M20.184 82.608c10.753-.525 18.918-12.244 18.237-26.174-.68-13.93-9.95-24.797-20.703-24.271S-1.2 44.407-.519 58.337s9.95 24.797 20.703 24.271"
            fill="#00b95c"
          />
        </g>
        <g filter="url(#f)">
          <path
            d="M20.184 82.608c10.753-.525 18.918-12.244 18.237-26.174-.68-13.93-9.95-24.797-20.703-24.271S-1.2 44.407-.519 58.337s9.95 24.797 20.703 24.271"
            fill="#00b95c"
          />
        </g>
        <g filter="url(#g)">
          <path
            d="M30.954 74.181c9.014-5.485 11.427-17.976 5.389-27.9-6.038-9.925-18.241-13.524-27.256-8.04-9.015 5.486-11.428 17.977-5.39 27.902 6.04 9.924 18.242 13.523 27.257 8.038"
            fill="#00b95c"
          />
        </g>
        <g filter="url(#h)">
          <path
            d="M67.391 42.993c10.132 0 18.346-7.91 18.346-17.666S77.523 7.66 67.391 7.66s-18.346 7.91-18.346 17.667 8.214 17.666 18.346 17.666"
            fill="#3186ff"
          />
        </g>
        <g filter="url(#i)">
          <path
            d="M-13.065 40.944c9.33 7.094 22.959 4.869 30.442-4.972 7.483-9.84 5.987-23.569-3.343-30.663S-8.924.439-16.408 10.28c-7.483 9.84-5.986 23.57 3.343 30.664"
            fill="#fbbc04"
          />
        </g>
        <g filter="url(#j)">
          <path
            d="M34.74 51.43c11.135 7.656 25.896 5.524 32.968-4.764s3.779-24.832-7.357-32.488C49.215 6.52 34.455 8.654 27.382 18.94c-7.072 10.288-3.779 24.833 7.357 32.49z"
            fill="#3186ff"
          />
        </g>
        <g filter="url(#k)">
          <path
            d="M54.984-2.336c2.833 3.852-.808 11.34-8.131 16.727s-15.557 6.631-18.39 2.78c-2.833-3.853.807-11.342 8.13-16.728s15.558-6.631 18.39-2.78z"
            fill="#749bff"
          />
        </g>
        <g filter="url(#l)">
          <path
            d="M31.727 16.104C43.053 5.598 46.94-8.626 40.41-15.666S19.404-19.898 8.078-9.392s-15.214 24.73-8.683 31.77c6.53 7.04 21.006 4.232 32.332-6.274"
            fill="#fc413d"
          />
        </g>
        <g filter="url(#m)">
          <path
            d="M8.51 53.838c6.732 4.818 14.46 5.55 17.262 1.636 2.802-3.915-.384-10.994-7.116-15.812s-14.46-5.55-17.261-1.636c-2.802 3.915.383 10.994 7.115 15.812"
            fill="#ffee48"
          />
        </g>
      </g>
      <defs>
        <filter
          id="c"
          x={-19.824}
          y={13.152}
          width={39.274}
          height={43.217}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur
            stdDeviation={2.46}
            result="effect1_foregroundBlur_2001_67"
          />
        </filter>
        <filter
          id="d"
          x={-15.001}
          y={-40.257}
          width={84.868}
          height={85.688}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur
            stdDeviation={11.891}
            result="effect1_foregroundBlur_2001_67"
          />
        </filter>
        <filter
          id="e"
          x={-20.776}
          y={11.927}
          width={79.454}
          height={90.916}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur
            stdDeviation={10.109}
            result="effect1_foregroundBlur_2001_67"
          />
        </filter>
        <filter
          id="f"
          x={-20.776}
          y={11.927}
          width={79.454}
          height={90.916}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur
            stdDeviation={10.109}
            result="effect1_foregroundBlur_2001_67"
          />
        </filter>
        <filter
          id="g"
          x={-19.845}
          y={15.459}
          width={79.731}
          height={81.505}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur
            stdDeviation={10.109}
            result="effect1_foregroundBlur_2001_67"
          />
        </filter>
        <filter
          id="h"
          x={29.832}
          y={-11.552}
          width={75.117}
          height={73.758}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur
            stdDeviation={9.606}
            result="effect1_foregroundBlur_2001_67"
          />
        </filter>
        <filter
          id="i"
          x={-38.583}
          y={-16.253}
          width={78.135}
          height={78.758}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur
            stdDeviation={8.706}
            result="effect1_foregroundBlur_2001_67"
          />
        </filter>
        <filter
          id="j"
          x={8.107}
          y={-5.966}
          width={78.877}
          height={77.539}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur
            stdDeviation={7.775}
            result="effect1_foregroundBlur_2001_67"
          />
        </filter>
        <filter
          id="k"
          x={13.587}
          y={-18.488}
          width={56.272}
          height={51.81}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur
            stdDeviation={6.957}
            result="effect1_foregroundBlur_2001_67"
          />
        </filter>
        <filter
          id="l"
          x={-15.526}
          y={-31.297}
          width={70.856}
          height={69.306}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur
            stdDeviation={5.876}
            result="effect1_foregroundBlur_2001_67"
          />
        </filter>
        <filter
          id="m"
          x={-14.168}
          y={20.964}
          width={55.501}
          height={51.571}
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity={0} result="BackgroundImageFix" />
          <feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur
            stdDeviation={7.273}
            result="effect1_foregroundBlur_2001_67"
          />
        </filter>
        <linearGradient
          id="a"
          x1={18.447}
          y1={43.42}
          x2={52.153}
          y2={15.004}
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#4893fc" />
          <stop offset={0.27} stopColor="#4893fc" />
          <stop offset={0.777} stopColor="#969dff" />
          <stop offset={1} stopColor="#bd99fe" />
        </linearGradient>
      </defs>
    </svg>
  );
};
